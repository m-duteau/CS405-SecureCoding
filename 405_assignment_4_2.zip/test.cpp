// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// Test that a single value can be added to an empty collection.
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, size must be 1
    ASSERT_EQ(collection->size(), 1);
}

// Test that 5 values can be added to a collection.
TEST_F(CollectionTest, CanAddMultipleValuesToVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, size must be 5
    ASSERT_EQ(collection->size(), 5);
}

// Test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries.
TEST_F(CollectionTest, MaxSizeIsGreaterEqualSize)
{
    // Check 0
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // max size must be greater than/equal to size
    ASSERT_GE(collection->max_size(), collection->size());

    // Check 1
    // add an entry
    add_entries(1);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 1
    ASSERT_EQ(collection->size(), 1);
    // max size must be greater than/equal to size
    ASSERT_GE(collection->max_size(), collection->size());

    // Check 5
    // add 4 entries
    add_entries(4);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 5
    ASSERT_EQ(collection->size(), 5);
    // max size must be greater than/equal to size
    ASSERT_GE(collection->max_size(), collection->size());

    // Check 10
    // add 5 entries
    add_entries(5);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 10
    ASSERT_EQ(collection->size(), 10);
    // max size must be greater than/equal to size
    ASSERT_GE(collection->max_size(), collection->size());
}

// Test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries.
TEST_F(CollectionTest, CapacityIsGreaterEqualSize)
{
    // Check 0
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // capacity must be greater than/equal to size
    ASSERT_GE(collection->capacity(), collection->size());

    // Check 1
    // add an entry
    add_entries(1);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 1
    ASSERT_EQ(collection->size(), 1);
    // capacity must be greater than/equal to size
    ASSERT_GE(collection->capacity(), collection->size());

    // Check 5
    // add 4 entries
    add_entries(4);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 5
    ASSERT_EQ(collection->size(), 5);
    // capacity must be greater than/equal to size
    ASSERT_GE(collection->capacity(), collection->size());

    // Check 10
    // add 5 entries
    add_entries(5);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 10
    ASSERT_EQ(collection->size(), 10);
    // capacity must be greater than/equal to size
    ASSERT_GE(collection->capacity(), collection->size());
}

// Test to verify resizing increases the collection.
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // hold current collection size
    int initialSize = collection->size();

    // resize to 3
    collection->resize(3);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 3
    ASSERT_EQ(collection->size(), 3);
    // check that resize increased the size
    ASSERT_GE(collection->size(), initialSize);
}

// Test to verify resizing decreases the collection.
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // add 10 entries
    add_entries(10);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 10
    ASSERT_EQ(collection->size(), 10);

    // hold current collection size
    int initialSize = collection->size();

    // resize to 3
    collection->resize(3);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 3
    ASSERT_EQ(collection->size(), 3);
    // check that resize decreased the size
    ASSERT_LE(collection->size(), initialSize);
}

// Test to verify resizing to 0 decreases the collection size to zero.
TEST_F(CollectionTest, ResizeCanDecreaseCollectionToZero)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // add 10 entries
    add_entries(10);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 10
    ASSERT_EQ(collection->size(), 10);

    // resize to 0
    collection->resize(0);

    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify clear erases the collection.
TEST_F(CollectionTest, ClearErasesTheCollection)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // add 10 entries
    add_entries(10);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 10
    ASSERT_EQ(collection->size(), 10);

    // clear the collection
    collection->clear();

    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify erase(begin,end) erases the collection.
TEST_F(CollectionTest, EraseErasesTheCollection)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // add 10 entries
    add_entries(10);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 10
    ASSERT_EQ(collection->size(), 10);

    // erase the collection from beginning to end
    collection->erase(collection->begin(), collection->end());

    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

// Test to verify reserve increases the capacity but not the size of the collection.
TEST_F(CollectionTest, ReserveIncreasesCapacityOfCollection)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // add 1 entry
    add_entries(1);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 1
    ASSERT_EQ(collection->size(), 1);

    // hold the current collection capacity
    int initialCapacity = collection->capacity();

    // reserve function using initialCapacity + 1
    collection->reserve(initialCapacity + 1);

    // check that capacity has increased
    ASSERT_GE(collection->capacity(), initialCapacity);
    // recheck that size is 1
    ASSERT_EQ(collection->size(), 1);
}

// Test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds.
// NOTE: This is a negative test
TEST_F(CollectionTest, ThrowOutOfRangeException)
{
    // hold collection size
    int collectionSize = collection->size();
    // check if the collection throws an exception out of range
    ASSERT_THROW(collection->at(collectionSize + 1), std::out_of_range);
}

// Custom Tests:
// Test to verify that collection can swap with another vector. (Positive)
TEST_F(CollectionTest, CollectionCanSwapWithAnotherVector)
{
    // create a new vector with basic values
    std::vector<int> x = { 0, 1, 2, 3, 4 };
    // hold vector size
    int initialTestVectorSize = x.size();

    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    // hold collection size
    int initialCollectionSize = collection->size();

    // swap the vector into collection
    collection->swap(x);

    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, confirm collection size matches initial vector size
    ASSERT_EQ(collection->size(), initialTestVectorSize);
    // confirm that vector size matches initial collection size
    ASSERT_EQ(x.size(), initialCollectionSize);
}

// Test to verify that std::lenth_error is thrown when resizing to a negative value. (Negative)
TEST_F(CollectionTest, CannotResizeToNegativeValue)
{
    ASSERT_THROW(collection->resize(-1), std::length_error);
}